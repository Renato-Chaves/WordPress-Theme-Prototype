		<footer>
		<div id="footer">&copy; <?php date('Y'); ?> <?php bloginfo('name'); ?> Theme was made by Renato Chaves.</div>
		</footer>
		</div>
	</div>
<?php wp_footer(); ?>
</body>
</html>